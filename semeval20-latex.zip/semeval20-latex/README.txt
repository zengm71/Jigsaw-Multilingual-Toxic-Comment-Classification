* Contents

Makefile	Makefile for compling coling 2020.tex in pdflatex
README.txt	This file
colig.bst		BibTeX `coling' style file
coling2020.dotx	Microsoft Word template file for Coling 2020
semeval2020.pdf	PDF file for SemEval 2020
coling2020.sty	LaTeX style file for Coling 2020
semeval2020.tex	LaTeX sample file for SemEval 2020
semeval2020.bib	LaTeX bib file for SemEval 2020
